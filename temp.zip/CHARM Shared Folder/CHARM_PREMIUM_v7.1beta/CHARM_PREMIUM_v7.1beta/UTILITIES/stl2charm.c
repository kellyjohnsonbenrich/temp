/* STLtoCHARM

  Command-line code to convert binary or ASCII STL formats to CHARM ASCII output.

  rmm, 10/23/08

  usage:

  stl2charm [-xyz 0.0 0.0 0.0] -i infile -o outfile

  */

//#define _WIN32_WINNT 0x0400
//#include <windows.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>

#define	NBUF 100

int main(int argc, char *argv[]){

	int		numPanels = 0;			// number of panels in STL input file
	float	vertex[] = {0.0, 0.0, 0.0};	 // storage for STL vertex read from input
	float	normal[3];				// normal vector for the panel (not used in CHARM)
	short  int	dummyInt;			// temporary output from read operation on STL file (16 bits)
	float	offset[] = {0.0, 0.0, 0.0};  // offset subtracted from STL file to make CHARM output
	char	title[NBUF];			// title line in binary STL file
	int		i;						// loop counter over panels
	int		j;						// loop counter over vertices of triangle
	char	*index;					// string location for token parsing in ASCII file processing
	int		isAscii = 0;			// flag to show type of STL file
	FILE	*fpi;					// pointer to input file
	FILE	*fpo;					// pointer to output file


	// parse input line to look for offset values, input and output filenames
	for (i=1;i<argc;i++) {	

		if (argv[i][0] == '-') { // trap on dash character for cmd line options
			switch (argv[i][1]) {

			case 'x':  // -xyz is the offset value
				offset[0] = (float) atof( &argv[i+1][0]);
				offset[1] = (float) atof( &argv[i+2][0]);
				offset[2] = (float) atof( &argv[i+3][0]);
				break;
				
			case 'o':  // -o is output filename
				fpo = fopen(argv[i+1],"w");
				if (fpo == NULL ) {
					printf("!!! Can't open output file: %s\n",argv[i+1]);
					exit(-1);
				}
				break;
				
			case 'i':  // -i is input filename
				// Note that we will open the file, and read the first 80 bytes to see
				// if this is ASCII format or binary.  If ASCII, we will close it and
				// re-open it appropriately.
				fpi = fopen(argv[i+1],"rb"); // assume reading binary file
				if (fpi == NULL ) {
					printf("!!! Can't open input file: %s\n",argv[i+1]);
					exit(-1);
				}
				// read in title line, look for ascii input file and treat appropriately
				fread(&title,80,1,fpi);
//				if (strnicmp(title,"solid",5) == 0) {  // ASCII format STL file header line test
				if ( (strncmp(title,"solid",5) == 0) | (strncmp(title,"SOLID",5) == 0) ) {  // ASCII format STL file header line test
					printf(" STL file is ASCII format.\n");
					freopen(argv[i+1],"r",fpi); // reopen file as ascii file
					isAscii = 1;  // set flag to show we're looking at an ASCII STL file now
					fgets(title,NBUF,fpi); // read first line ... again
					printf(" Title : %s\n",title); // echo to console window
				} else {
					printf(" STL file is binary format.\n");
				}
				break;

			case '?':
				printf("Usage: stl2charm -i inputfile -o outputfile <-xyz x_offset y_offset z_offset> <-?>\n\n");
				break;

			}
		}

	}


	// read in number of panels (if binary)
	if (!isAscii) {
		fread(&numPanels,sizeof(int),1,fpi);
		printf(" Number of panels : %d\n",numPanels);
	}

	// open output stream and start writing
	fprintf(fpo,"%10.0d\n",numPanels);	// we write 0 for this initially if an ASCII file since we have to count!

	// the great divide: different processing for ASCII versus binary STL file formats

	if (isAscii) {

		// Panel block processing:
		//  Each group has a line defining a normal, then separators around three vertices,
		//  that define the panel.  The end of the ASCII file is found from the keyword "endsolid",
		//  so we trap for that to determine when we're done reading.  The output file is "rewound" to the
		//  beginning so we can write out the number of panels in the lot.

		while (1) {
			fgets(title,NBUF,fpi); // read facet normal line -OR- endsolid keyword

			if ( strstr(title,"endsolid") != NULL ) { // hits true if we're at the end
				printf(" Found the last line of the ASCII file, with numPanels = %d\n",numPanels);
				rewind(fpo);
				fprintf(fpo,"%10.0d\n",numPanels);	// copy over the proper number of panels to the CHARM file
				fclose(fpi);	// close out our file i/o
				fclose(fpo);
				exit(0);		// THIS IS THE ASCII PROCESSING EXIT LOCATION (sorry, within a while loop!)
			}
			fgets(title,NBUF,fpi); // read outer loop line
			fprintf(fpo," 3\n");  // write number of points in this panel

			for (j=0; j<3; j++) {
				fgets(title,NBUF,fpi); // read vertex line
				index = 6 + strstr(title,"vertex");
				sscanf(index,"%f %f %f",&vertex[0],&vertex[1],&vertex[2]);
				// write out vertex triple
				fprintf(fpo," %g %g %g\n",vertex[0]+offset[0],vertex[1]+offset[1],vertex[2]+offset[2]);
			}
			numPanels++;			// bump up count on panels

			fgets(title,NBUF,fpi); // read endloop line
			fgets(title,NBUF,fpi); // read endfacet line
		}

	} else {

		// loop over all panels and output the vertices
		for (i = 0; i < numPanels; i++ ) {

			// read in 3-vector normal
			fread(&normal[0],sizeof(float),3,fpi);
			fprintf(fpo," 3\n");  // write number of points in this panel

			for ( j = 0; j < 3; j++ ) { // loop over vertices of triangle

				fread(&vertex[0],sizeof(float),3,fpi);

				fprintf(fpo," %g %g %g\n",vertex[0]+offset[0],vertex[1]+offset[1],vertex[2]+offset[2]); // write out vertex triple
			}
			fread(&dummyInt,sizeof(short int),1,fpi); // read "color" info from STL file

		}

	}

	// we only get here if we're looking at a binary STL format file ...

	fclose(fpi);
	fclose(fpo);

}
