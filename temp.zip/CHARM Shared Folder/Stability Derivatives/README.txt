5-25-2022,

Today I uploaded a new release of the automated method for calculating
stability derivatives with CHARM.  This includes a bug fix that applies
particularly to the dFz/dq stability derivative.

To get started, read the PDF and download the gz zipped archive
to your LINUX machine and uncompress the archive by typing:

zcat STABILITY_DERIVATIVES_5-25-22.tar.gz | (tar xf -)

Then follow the instructions in the README file in that directory.
Also in that directory is CHARM VERSION 7.1 which has the bug fix
required to get proper the proper dFz/dq stability derivative.

DAW
5/25/22 